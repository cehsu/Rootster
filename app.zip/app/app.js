'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [
  'ngRoute',
  'firebase',
  'myApp.view1',
  'myApp.view2',
  'myApp.version'
]).
config(['$locationProvider', '$routeProvider', '$firebaseRefProvider', function($locationProvider, $routeProvider, $firebaseRefProvider) {
  var config = {
    apiKey: "AIzaSyA_AIzrNs3-mEQ0NkBMZrrw2RjmQPdI0hw",
    authDomain: "rootster-665cb.firebaseapp.com",
    databaseURL: "https://rootster-665cb.firebaseio.com"
  };
  console.log("in configview2");
  firebase.initializeApp(config);
  var rootRef = firebase.database().ref();
  $firebaseRefProvider.registerUrl("https://rootster-665cb.firebaseio.com");


  $locationProvider.hashPrefix('!');
//   $locationProvider.html5Mode({
//   enabled: true,
//   requireBase: false
// });

  $routeProvider.otherwise({redirectTo: '/view1'});
}]);
